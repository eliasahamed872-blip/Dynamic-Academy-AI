# Dynamic Academy AI — Android starter project

A futuristic Android Studio starter app for Dynamic Academy AI.

## Open and run
1. Install Android Studio (current stable version).
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the `DynamicAcademyAI` folder.
4. Allow Gradle sync, then run on an Android phone or emulator.

## Included in this starter
- Futuristic dark JARVIS-inspired interface
- Home dashboard and bottom navigation
- Chat preview UI
- Android speech-to-text input launcher
- School tools menu for marks, attendance, notices, timetable and Annual Week
- Creation menu for images, PDFs, notices and lesson plans

## Important: live AI is not connected yet
The chat currently returns a setup message. Live AI chat and image generation require a secure backend/API integration. Do not put a private API key directly in the Android app. Add a backend service and connect the app to it before publishing.

## Package
`com.dynamicacademy.ai`

## Build an APK using GitHub Actions (no computer required)
1. Create a new **public or private** GitHub repository.
2. On GitHub in your mobile browser, upload the *contents* of this project folder (including the hidden `.github/workflows/android.yml` file). If the mobile upload screen cannot upload folders/hidden files, use GitHub's web editor or a computer.
3. Open the repository's **Actions** tab.
4. Select **Build Dynamic Academy AI APK**, then choose **Run workflow** (or push to `main`).
5. Open the completed workflow run, scroll to **Artifacts**, and download `Dynamic-Academy-AI-debug-apk`.
6. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.

This creates a debug APK for testing, not a Play Store release. The app is a starter UI; live AI services still need a secure backend/API connection.
