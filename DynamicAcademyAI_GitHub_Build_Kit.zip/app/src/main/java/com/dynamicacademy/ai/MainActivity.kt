package com.dynamicacademy.ai

import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF050B16)
private val Panel = Color(0xFF0C1728)
private val Cyan = Color(0xFF38D9FF)
private val Muted = Color(0xFF9AB0C8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DynamicAcademyApp() }
    }
}

data class ChatLine(val text: String, val fromUser: Boolean)

@Composable
fun DynamicAcademyApp() {
    var message by remember { mutableStateOf("") }
    var selected by remember { mutableStateOf("Home") }
    var chat by remember { mutableStateOf(listOf(ChatLine("Hello! I am Dynamic Academy AI. How can I help you today?", false))) }
    var notice by remember { mutableStateOf("AI services are ready to be connected. Add your secure AI backend to enable live answers.") }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) message = spoken
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Cyan,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF08172A), Bg, Color(0xFF03070D)))
            ).padding(horizontal = 18.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Cyan.copy(alpha=.12f), CircleShape).border(1.dp, Cyan.copy(alpha=.6f), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.AutoAwesome, null, tint = Cyan)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("DYNAMIC ACADEMY", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text("AI ASSISTANT  •  JARVIS MODE", color = Cyan, fontSize = 10.sp, letterSpacing = 1.5.sp)
                }
                Icon(Icons.Default.Settings, "Settings", tint = Muted)
            }

            when (selected) {
                "Home" -> {
                    Spacer(Modifier.height(12.dp))
                    Text("GOOD DAY", color = Muted, fontSize = 11.sp, letterSpacing = 3.sp)
                    Text("How can I help?", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(22.dp))
                    Box(Modifier.fillMaxWidth().height(210.dp), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(188.dp).border(1.dp, Cyan.copy(alpha=.22f), CircleShape).padding(12.dp).border(1.dp, Cyan.copy(alpha=.35f), CircleShape).padding(13.dp).border(2.dp, Cyan.copy(alpha=.7f), CircleShape), contentAlignment = Alignment.Center) {
                            Box(Modifier.size(112.dp).background(Brush.radialGradient(listOf(Cyan.copy(alpha=.32f), Color(0xFF102D49), Color.Transparent)), CircleShape).border(1.dp, Cyan, CircleShape), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.GraphicEq, null, tint = Cyan, modifier = Modifier.size(52.dp))
                            }
                        }
                        Text("ONLINE", Modifier.align(Alignment.BottomCenter).padding(bottom = 3.dp), color = Cyan, fontSize = 11.sp, letterSpacing = 3.sp)
                    }
                    Text("YOUR AI CONTROL CENTER", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(12.dp))
                    val features = listOf(
                        Triple("AI Chat", "Ask anything", Icons.Default.Chat),
                        Triple("Voice Assistant", "Talk to your AI", Icons.Default.Mic),
                        Triple("School Tools", "Notices • Marks • Timetable", Icons.Default.School),
                        Triple("Create", "Images • PDFs • Documents", Icons.Default.AutoFixHigh)
                    )
                    features.chunked(2).forEach { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            pair.forEach { f ->
                                FeatureCard(f.first, f.second, f.third, Modifier.weight(1f)) {
                                    selected = if (f.first == "School Tools") "School" else if (f.first == "Create") "Create" else "Chat"
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                    }
                }
                "Chat" -> {
                    Text("AI CONVERSATION", color = Cyan, fontSize = 11.sp, letterSpacing = 2.sp)
                    LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(chat) { line ->
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start) {
                                Surface(color = if (line.fromUser) Color(0xFF12334A) else Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.widthIn(max = 300.dp)) {
                                    Text(line.text, Modifier.padding(13.dp), color = Color.White, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(value = message, onValueChange = { message = it }, modifier = Modifier.weight(1f), placeholder = { Text("Message Dynamic AI…") }, shape = RoundedCornerShape(18.dp), singleLine = true)
                        Spacer(Modifier.width(7.dp))
                        IconButton(onClick = {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            }
                            runCatching { speechLauncher.launch(intent) }
                        }) { Icon(Icons.Default.Mic, "Voice input", tint = Cyan) }
                        IconButton(onClick = {
                            if (message.isNotBlank()) {
                                chat = chat + ChatLine(message, true) + ChatLine("This is the starter preview. Connect a secure AI backend to enable live AI responses.", false)
                                message = ""
                            }
                        }) { Icon(Icons.Default.Send, "Send", tint = Cyan) }
                    }
                    Spacer(Modifier.height(14.dp))
                }
                "School" -> {
                    Text("SCHOOL COMMAND CENTER", color = Cyan, fontSize = 11.sp, letterSpacing = 2.sp)
                    Text("Dynamic Academy, Kathlijhar", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp, bottom = 18.dp))
                    listOf("Student Marks & Results", "Attendance Management", "Notices & Circulars", "Class Timetable", "Annual Week Planner").forEach {
                        Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { notice = "$it selected. This module can be connected to your school data." }) {
                            Row(Modifier.padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.School, null, tint = Cyan)
                                Spacer(Modifier.width(12.dp))
                                Text(it, Modifier.weight(1f), color = Color.White)
                                Icon(Icons.Default.ChevronRight, null, tint = Muted)
                            }
                        }
                    }
                    Text(notice, color = Muted, fontSize = 12.sp)
                }
                else -> {
                    Text("AI CREATION STUDIO", color = Cyan, fontSize = 11.sp, letterSpacing = 2.sp)
                    Text("Bring your ideas to life.", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 14.dp))
                    listOf("Generate an AI image", "Create a school notice", "Build a PDF document", "Draft a lesson plan").forEach {
                        Surface(color = Panel, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp).clickable { notice = "$it — connect the relevant AI service to activate this tool." }) {
                            Text(it, Modifier.padding(18.dp), color = Color.White)
                        }
                    }
                    Text(notice, color = Muted, fontSize = 12.sp)
                }
            }

            NavigationBar(containerColor = Color(0xFF07111F), contentColor = Cyan) {
                listOf("Home", "Chat", "School", "Create").forEach { item ->
                    NavigationBarItem(
                        selected = selected == item,
                        onClick = { selected = item },
                        icon = {
                            Icon(when(item) {
                                "Home" -> Icons.Default.Home
                                "Chat" -> Icons.Default.Chat
                                "School" -> Icons.Default.School
                                else -> Icons.Default.AutoAwesome
                            }, contentDescription = item)
                        },
                        label = { Text(item, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, selectedTextColor = Cyan, indicatorColor = Cyan.copy(alpha=.12f), unselectedIconColor = Muted, unselectedTextColor = Muted)
                    )
                }
            }
        }
    }
}

@Composable
fun FeatureCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Surface(color = Panel.copy(alpha=.92f), shape = RoundedCornerShape(16.dp), modifier = modifier.height(112.dp).border(1.dp, Cyan.copy(alpha=.14f), RoundedCornerShape(16.dp)).clickable(onClick = onClick)) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(23.dp))
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(subtitle, color = Muted, fontSize = 10.sp)
            }
        }
    }
}
